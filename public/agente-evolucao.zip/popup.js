const DEFAULT_URL = "https://projeto-carinhoso-agora.lovable.app";
const $ = (id) => document.getElementById(id);

chrome.storage.local.get(["panelUrl", "apiKey"], (cfg) => {
  if (cfg.panelUrl) { $("panelUrl").value = cfg.panelUrl; } else { $("panelUrl").value = DEFAULT_URL; }
  if (cfg.apiKey) $("apiKey").value = cfg.apiKey;
});

$("save").addEventListener("click", async () => {
  const panelUrl = DEFAULT_URL;
  const status = $("status");
  status.textContent = "Buscando chave...";
  status.className = "status";

  try {
    // Tenta pegar a chave do painel (logado no browser)
    const response = await fetch(`${panelUrl}/api/public/extension/therapist`);
    if (!response.ok) throw new Error("Não foi possível obter a configuração. Verifique se você está logado no painel.");
    
    const data = await response.json();
    const apiKey = data.apiKey;

    if (!apiKey) {
      throw new Error("API Key não encontrada. Gere uma chave nas configurações do painel.");
    }

    status.textContent = "Testando conexão...";
    const r = await fetch(`${panelUrl}/api/public/extension/generate`, {
      method: "OPTIONS",
      headers: { "x-api-key": apiKey },
    });
    if (!r.ok && r.status !== 204) throw new Error(`Falha na validação (HTTP ${r.status})`);

    await chrome.storage.local.set({ panelUrl, apiKey });
    status.textContent = "Conectado com sucesso!";
    status.className = "status ok";
    
    // Preenche os campos ocultos para feedback visual se o usuário abrir o popup de novo
    $("panelUrl").value = panelUrl;
    $("apiKey").value = apiKey;

  } catch (e) {
    status.textContent = "Erro: " + e.message;
    status.className = "status err";
  }
});
