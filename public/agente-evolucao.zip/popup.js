const DEFAULT_URL = "https://projeto-carinhoso-agora.lovable.app";
const $ = (id) => document.getElementById(id);

chrome.storage.local.get(["panelUrl", "apiKey"], (cfg) => {
  if (cfg.panelUrl) { $("panelUrl").value = cfg.panelUrl; } else { $("panelUrl").value = DEFAULT_URL; }
  if (cfg.apiKey) $("apiKey").value = cfg.apiKey;
});

$("save").addEventListener("click", async () => {
  const panelUrl = DEFAULT_URL;
  const status = $("status");
  status.textContent = "Buscando configuração...";
  status.className = "status";

  try {
    // 1. Busca dados do terapeuta e verifica se está logado
    const response = await fetch(`${panelUrl}/api/public/extension/therapist`);
    if (!response.ok) {
      if (response.status === 401) throw new Error("Não autorizado. Você precisa estar logado no Painel neste navegador.");
      throw new Error("Erro ao acessar o painel. Verifique se o site está online.");
    }
    
    const data = await response.json();
    
    // Tenta obter a chave do storage se não veio no JSON (já que não salvamos a plana no DB por segurança)
    let apiKey = (await chrome.storage.local.get(["apiKey"])).apiKey;

    if (!apiKey) {
      status.textContent = "Chave não encontrada. Por favor, crie uma chave em 'Configurações' no Painel e tente novamente.";
      status.className = "status err";
      return;
    }

    status.textContent = "Verificando conexão...";
    const r = await fetch(`${panelUrl}/api/public/extension/generate`, {
      method: "OPTIONS",
      headers: { "x-api-key": apiKey },
    });
    
    if (!r.ok && r.status !== 204) {
      throw new Error(`A chave atual é inválida (HTTP ${r.status}). Gere uma nova chave no Painel.`);
    }

    await chrome.storage.local.set({ panelUrl, apiKey });
    status.textContent = "Conectado e Configurado!";
    status.className = "status ok";
    
    $("panelUrl").value = panelUrl;
    $("apiKey").value = apiKey;

  } catch (e) {
    status.textContent = "Erro: " + e.message;
    status.className = "status err";
  }
});
