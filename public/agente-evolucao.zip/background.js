// Service worker — proxy para chamadas ao painel (evita CORS no content script)
// Mantém a resposta assíncrona viva e devolve mensagens de erro úteis.

// Ao clicar no ícone da extensão, abre o chat na aba ativa (se for clínica nas nuvens)
// ou injeta o content script e tenta novamente.
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  const trySend = () =>
    chrome.tabs.sendMessage(tab.id, { type: "open-chat" }).catch(() => null);
  let resp = await trySend();
  if (!resp) {
    // injeta o content script (caso a página não tenha disparado o match ainda)
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await new Promise((r) => setTimeout(r, 200));
      resp = await trySend();
    } catch (e) {
      // página não permite injeção (ex: chrome://). Abre uma nova aba do painel.
      const cfg = await chrome.storage.local.get(["panelUrl"]);
      if (cfg.panelUrl) chrome.tabs.create({ url: cfg.panelUrl });
    }
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "generate" && msg?.type !== "confirm" && msg?.type !== "chat-generate" && msg?.type !== "fetch-therapist") return;

  (async () => {
    try {
      const cfg = await chrome.storage.local.get(["panelUrl", "apiKey"]);
      if (!cfg.panelUrl || !cfg.apiKey) {
        sendResponse({ ok: false, error: "Configure URL e API key no popup da extensão." });
        return;
      }
      const pathMap = {
        generate: "/api/public/extension/generate",
        confirm: "/api/public/extension/confirm",
        "chat-generate": "/api/public/extension/chat-generate",
        "fetch-therapist": "/api/public/extension/therapist",
      };
      const url = `${cfg.panelUrl.replace(/\/$/, "")}${pathMap[msg.type]}`;
      const method = msg.type === "fetch-therapist" ? "GET" : "POST";

      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 80000);

      let resp;
      try {
        resp = await fetch(url, {
          method,
          headers: { "Content-Type": "application/json", "x-api-key": cfg.apiKey },
          body: method === "GET" ? undefined : JSON.stringify(msg.payload ?? {}),
          signal: ctrl.signal,
        });
      } catch (e) {
        clearTimeout(timer);
        if (e.name === "AbortError") {
          sendResponse({ ok: false, error: "A IA demorou demais (>80s). Tente novamente." });
        } else {
          sendResponse({ ok: false, error: `Falha de rede: ${e.message}` });
        }
        return;
      }
      clearTimeout(timer);

      const text = await resp.text();
      let data = {};
      try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text?.slice(0, 200) }; }
      if (!resp.ok) {
        sendResponse({ ok: false, error: data.error || `HTTP ${resp.status}` });
        return;
      }
      sendResponse({ ok: true, data });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();

  return true; // mantém o canal aberto para sendResponse assíncrono
});
