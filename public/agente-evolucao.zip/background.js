// Service worker — proxy para chamadas ao painel (evita CORS no content script)
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  const trySend = () =>
    chrome.tabs.sendMessage(tab.id, { type: "open-chat" }).catch(() => null);
  let resp = await trySend();
  if (!resp) {
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await new Promise((r) => setTimeout(r, 200));
      resp = await trySend();
    } catch (e) {
      let cfg = await chrome.storage.local.get(["panelUrl"]); 
      const DEFAULT_URL = "https://projeto-carinhoso-agora.lovable.app";
      if(!cfg.panelUrl) cfg.panelUrl = DEFAULT_URL;
      chrome.tabs.create({ url: cfg.panelUrl });
    }
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "generate" && msg?.type !== "confirm" && msg?.type !== "chat-generate" && msg?.type !== "fetch-therapist") return;

  (async () => {
    try {
      let cfg = await chrome.storage.local.get(["panelUrl", "apiKey"]);
      const DEFAULT_PANEL_URL = "https://projeto-carinhoso-agora.lovable.app";
      
      if (!cfg.panelUrl) {
        cfg.panelUrl = DEFAULT_PANEL_URL;
        await chrome.storage.local.set({ panelUrl: DEFAULT_PANEL_URL });
      }
      
      if (!cfg.apiKey && msg.type !== "fetch-therapist") {
        sendResponse({ ok: false, error: "Extensão não conectada. Abra o ícone da extensão e clique em 'Conectar automaticamente'." });
        return;
      }

      const pathMap = {
        generate: "/api/public/extension/generate",
        confirm: "/api/public/extension/confirm",
        "chat-generate": "/api/public/extension/chat-generate",
        "fetch-therapist": "/api/public/extension/therapist",
      };
      
      const baseUrl = cfg.panelUrl.replace(/\/$/, "");
      const url = `${baseUrl}${pathMap[msg.type]}`;
      const method = msg.type === "fetch-therapist" ? "GET" : "POST";

      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 95000);

      try {
        const headers = { 
          "Content-Type": "application/json",
          "Accept": "application/json"
        };
        if (cfg.apiKey) {
          headers["x-api-key"] = cfg.apiKey;
        }

        const resp = await fetch(url, {
          method,
          headers,
          body: method === "GET" ? undefined : JSON.stringify(msg.payload ?? {}),
          signal: ctrl.signal,
        });

        clearTimeout(timer);
        const text = await resp.text();
        let data = {};
        try { 
          data = text ? JSON.parse(text) : {}; 
        } catch { 
          data = { error: "Resposta inválida do servidor." }; 
        }
        
        if (!resp.ok) {
          sendResponse({ ok: false, error: data.error || `Erro do Servidor (${resp.status})` });
        } else {
          sendResponse({ ok: true, data });
        }
      } catch (e) {
        clearTimeout(timer);
        if (e.name === "AbortError") {
          sendResponse({ ok: false, error: "Timeout: O servidor demorou demais." });
        } else {
          sendResponse({ ok: false, error: "Erro de Conexão: Verifique se você está logado no painel e se a internet está ativa." });
        }
      }
    } catch (e) {
      sendResponse({ ok: false, error: "Erro Interno: " + e.message });
    }
  })();

  return true; 
});
