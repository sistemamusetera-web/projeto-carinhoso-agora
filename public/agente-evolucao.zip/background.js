// Service worker — proxy para chamadas ao painel (evita CORS no content script)
// Mantém a resposta assíncrona viva e devolve mensagens de erro úteis.

// Ao clicar no ícone da extensão, abre o chat na aba ativa (se for clínica nas nuvens)
// ou injeta o content script e tenta novamente.
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  const trySend = () =>
    chrome.tabs.sendMessage(tab.id, { type: "open-chat" }).catch(() => null);
  let resp = await trySend();
  if (!resp) {
    // injeta o content script (caso a página não tenha disparado o match ainda)
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await new Promise((r) => setTimeout(r, 200));
      resp = await trySend();
    } catch (e) {
      // página não permite injeção (ex: chrome://). Abre uma nova aba do painel.
      let cfg = await chrome.storage.local.get(["panelUrl"]); 
      const DEFAULT_URL = "https://projeto-carinhoso-agora.lovable.app";
      if(!cfg.panelUrl) cfg.panelUrl = DEFAULT_URL;
      chrome.tabs.create({ url: cfg.panelUrl });
    }
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "generate" && msg?.type !== "confirm" && msg?.type !== "chat-generate" && msg?.type !== "fetch-therapist") return;

  (async () => {
    try {
      let cfg = await chrome.storage.local.get(["panelUrl", "apiKey"]);
      const DEFAULT_PANEL_URL = "https://projeto-carinhoso-agora.lovable.app";
      
      if (!cfg.panelUrl) {
        cfg.panelUrl = DEFAULT_PANEL_URL;
        chrome.storage.local.set({ panelUrl: DEFAULT_PANEL_URL });
      }
      
      if (!cfg.apiKey) {
        sendResponse({ ok: false, error: "API Key não configurada. Vá às Configurações no Painel e cole a chave no ícone da extensão." });
        return;
      }

      const pathMap = {
        generate: "/api/public/extension/generate",
        confirm: "/api/public/extension/confirm",
        "chat-generate": "/api/public/extension/chat-generate",
        "fetch-therapist": "/api/public/extension/therapist",
      };
      const url = `${cfg.panelUrl.replace(/\/$/, "")}${pathMap[msg.type]}`;
      const method = msg.type === "fetch-therapist" ? "GET" : "POST";

      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 95000); // 95s para Gemini

      let resp;
      try {
        resp = await fetch(url, {
          method,
          headers: { 
            "Content-Type": "application/json", 
            "x-api-key": cfg.apiKey,
            "Accept": "application/json"
          },
          body: method === "GET" ? undefined : JSON.stringify(msg.payload ?? {}),
          signal: ctrl.signal,
        });
      } catch (e) {
        clearTimeout(timer);
        if (e.name === "AbortError") {
          sendResponse({ ok: false, error: "O servidor demorou demais para responder. Tente novamente." });
        } else {
          sendResponse({ ok: false, error: "Erro de Conexão: O site não respondeu. Verifique se o Painel está aberto e se a URL está correta." });
        }
        return;
      }
      clearTimeout(timer);

      const text = await resp.text();
      let data = {};
      try { 
        data = text ? JSON.parse(text) : {}; 
      } catch { 
        data = { error: "Resposta inválida do servidor. Verifique se a URL do painel está correta." }; 
      }
      
      if (!resp.ok) {
        sendResponse({ ok: false, error: data.error || `Erro do Servidor (${resp.status})` });
        return;
      }
      sendResponse({ ok: true, data });
    } catch (e) {
      sendResponse({ ok: false, error: "Erro Interno: " + e.message });
    }
  })();

  return true; 
});
